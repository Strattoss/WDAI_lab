Chciałem jedynie pana poinformować, że baza danych dla aplikacji z tego
laboratorium jest inną bazą danych niż dla laboratorium poprzedniego,
gdyż wprowadzenianie modyfikacji w dotychczasowej bazie
uniemożliwiłoby poprawne działanie programu z laboratorium 5.
Dodatkowo, poniżej podaję utworzone już konta użytkowników
o odpowiednich rolach.
Pozdrawiam, Gracjan Filipek

(email, hasło)
admin@admin.com, admin123
banned@banned.com, banned123
client@client.com, client123
manager@manager.com, manager123