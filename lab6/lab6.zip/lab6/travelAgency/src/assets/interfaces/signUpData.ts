// interface for register form
export interface SignUpData {
    firstName: string,
    lastName: string,
    email: string
}