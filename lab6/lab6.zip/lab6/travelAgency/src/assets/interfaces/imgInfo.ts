export interface ImgInfo {
    alt: string,
    srcThumbnail: string;
    srcFull: string;
    title: string
}