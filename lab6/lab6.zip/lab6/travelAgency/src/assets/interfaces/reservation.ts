import { TripId } from "../types/tripId";

export interface Reservation {
    id: TripId,
    tickets: number
}