export interface Roles {
    client: boolean,
    manager: boolean,
    admin: boolean,
    banned: boolean
}