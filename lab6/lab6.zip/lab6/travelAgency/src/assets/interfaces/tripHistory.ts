export interface TripHistory {
    tripId: string,
    tickets: number,
    date: string
  }