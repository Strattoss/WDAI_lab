export const firebaseConfig = {
    apiKey: "AIzaSyA7qi0eIGbaGUPH4xGmGupIr9qnkb5t_UU",
    authDomain: "travelagencywdailab6.firebaseapp.com",
    projectId: "travelagencywdailab6",
    storageBucket: "travelagencywdailab6.appspot.com",
    messagingSenderId: "906406865469",
    appId: "1:906406865469:web:48ce155bb1808e44b69854",
    databaseURL: "https://travelagencywdailab6-default-rtdb.europe-west1.firebasedatabase.app"
  };