export const environment = {
    production: false,
    firebaseConfig: {
        apiKey: "AIzaSyBnkyOxFwG6lp5BMfy4jpA0XzhiOopWPNA",
        authDomain: "travelagencywdai.firebaseapp.com",
        databaseURL: "https://travelagencywdai-default-rtdb.europe-west1.firebasedatabase.app",
        projectId: "travelagencywdai",
        storageBucket: "travelagencywdai.appspot.com",
        messagingSenderId: "769773708049",
        appId: "1:769773708049:web:d7e8792a47f6f8a282a2b0"
    }
}