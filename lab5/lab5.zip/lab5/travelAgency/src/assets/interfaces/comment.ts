export interface Comment {
    nick: string,
    tripTitle: string | undefined
    content: string
}