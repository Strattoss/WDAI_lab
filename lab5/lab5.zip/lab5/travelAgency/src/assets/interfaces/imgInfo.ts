import { ImgUrl } from "./ImgUrl"

export interface ImgInfo {
    alt: string,
    title: string
    imgs: ImgUrl[]
}