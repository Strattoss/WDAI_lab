export interface ImgUrl {
        src: string,
        width: number
}